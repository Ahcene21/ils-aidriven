import { useState } from 'react'
import { Send, Loader2, Sparkles, MessageSquare } from 'lucide-react'
import { api } from '../services/api'

const exampleQueries = [
  "What was the checkout count last month?",
  "Show me top 10 juvenile fiction books",
  "Compare branch performance this quarter",
  "What is the renewal rate for DVDs?",
]

export default function AIQuery() {
  const [query, setQuery] = useState('')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!query.trim()) return

    setLoading(true)
    setError(null)
    setResult(null)

    try {
      const data = await api.queryAI(query)
      setResult(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleExample = (q) => {
    setQuery(q)
    setResult(null)
    setError(null)
  }

  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-6">
        <Sparkles className="w-5 h-5 text-primary-600" />
        <h3 className="text-lg font-semibold text-gray-900">AI Natural Language Query</h3>
      </div>

      {/* Example queries */}
      <div className="flex flex-wrap gap-2 mb-4">
        {exampleQueries.map((q) => (
          <button
            key={q}
            onClick={() => handleExample(q)}
            className="text-xs px-3 py-1.5 bg-gray-100 text-gray-600 rounded-full hover:bg-primary-50 hover:text-primary-700 transition-colors"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="flex gap-3 mb-6">
        <div className="flex-1 relative">
          <MessageSquare className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask anything about your library data..."
            className="input pl-10"
          />
        </div>
        <button
          type="submit"
          disabled={loading || !query.trim()}
          className="btn-primary flex items-center gap-2"
        >
          {loading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Send className="w-4 h-4" />
          )}
          Ask
        </button>
      </form>

      {/* Error */}
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm mb-4">
          {error}
        </div>
      )}

      {/* Results */}
      {result && (
        <div className="space-y-4">
          {result.explanation && (
            <div className="p-3 bg-primary-50 border border-primary-100 rounded-lg">
              <p className="text-sm text-primary-800">
                <span className="font-semibold">Explanation:</span> {result.explanation}
              </p>
            </div>
          )}

          {result.sql && (
            <div className="bg-gray-900 rounded-lg p-4 overflow-x-auto">
              <p className="text-xs text-gray-400 mb-2 font-mono">Generated SQL:</p>
              <code className="text-sm text-green-400 font-mono whitespace-pre">
                {result.sql}
              </code>
            </div>
          )}

          {result.results && result.results.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-200">
                    {Object.keys(result.results[0]).map((key) => (
                      <th key={key} className="text-left py-2 px-3 text-xs font-semibold text-gray-500 uppercase">
                        {key}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {result.results.map((row, i) => (
                    <tr key={i} className="hover:bg-gray-50">
                      {Object.values(row).map((val, j) => (
                        <td key={j} className="py-2 px-3 text-gray-700">
                          {typeof val === 'number' ? val.toLocaleString() : String(val)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {result.results && result.results.length === 0 && (
            <div className="text-center py-8 text-gray-400 text-sm">
              Query executed successfully but returned no results.
            </div>
          )}
        </div>
      )}
    </div>
  )
}
