import { useState } from 'react'
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, 
  Tooltip, Legend, ResponsiveContainer, AreaChart, Area 
} from 'recharts'
import { Calendar } from 'lucide-react'

const eventTypeColors = {
  checkout: '#3b82f6',
  renewal: '#10b981',
  return: '#f59e0b',
  hold_placed: '#8b5cf6',
  hold_filled: '#ec4899',
}

export default function TrendChart({ data, loading }) {
  const [chartType, setChartType] = useState('line')

  if (loading) {
    return (
      <div className="card">
        <div className="h-6 bg-gray-200 rounded w-1/4 mb-6 animate-pulse"></div>
        <div className="h-80 bg-gray-100 rounded animate-pulse"></div>
      </div>
    )
  }

  if (!data || data.length === 0) {
    return (
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <Calendar className="w-5 h-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Circulation Trends</h3>
        </div>
        <div className="h-80 flex items-center justify-center text-gray-400">
          No trend data available. Run a sync to populate data.
        </div>
      </div>
    )
  }

  // Get all event type keys (excluding 'period')
  const eventTypes = Object.keys(data[0]).filter(k => k !== 'period')

  const ChartComponent = chartType === 'area' ? AreaChart : LineChart

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Circulation Trends</h3>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setChartType('line')}
            className={`px-3 py-1 text-xs rounded-md font-medium transition-colors ${
              chartType === 'line' 
                ? 'bg-primary-100 text-primary-700' 
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Line
          </button>
          <button
            onClick={() => setChartType('area')}
            className={`px-3 py-1 text-xs rounded-md font-medium transition-colors ${
              chartType === 'area' 
                ? 'bg-primary-100 text-primary-700' 
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Area
          </button>
        </div>
      </div>

      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <ChartComponent data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis 
              dataKey="period" 
              tick={{ fontSize: 12 }}
              stroke="#9ca3af"
            />
            <YAxis 
              tick={{ fontSize: 12 }}
              stroke="#9ca3af"
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }}
            />
            <Legend />
            {eventTypes.map((type) => (
              chartType === 'area' ? (
                <Area
                  key={type}
                  type="monotone"
                  dataKey={type}
                  stroke={eventTypeColors[type] || '#6b7280'}
                  fill={eventTypeColors[type] || '#6b7280'}
                  fillOpacity={0.1}
                  strokeWidth={2}
                />
              ) : (
                <Line
                  key={type}
                  type="monotone"
                  dataKey={type}
                  stroke={eventTypeColors[type] || '#6b7280'}
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 4 }}
                />
              )
            ))}
          </ChartComponent>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
