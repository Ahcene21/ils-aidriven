import { Users, Activity } from 'lucide-react'

const ageGroupColors = {
  '0-12': 'bg-blue-100 text-blue-700',
  '13-17': 'bg-green-100 text-green-700',
  '18-25': 'bg-yellow-100 text-yellow-700',
  '26-64': 'bg-purple-100 text-purple-700',
  '65+': 'bg-red-100 text-red-700',
}

const patronTypeLabels = {
  student: 'Students',
  faculty: 'Faculty',
  staff: 'Staff',
  juvenile: 'Juvenile',
  senior: 'Seniors',
  community: 'Community',
  other: 'Other',
}

export default function PatronSegments({ data, loading }) {
  if (loading) {
    return (
      <div className="card">
        <div className="h-6 bg-gray-200 rounded w-1/3 mb-6 animate-pulse"></div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 bg-gray-100 rounded animate-pulse"></div>
          ))}
        </div>
      </div>
    )
  }

  if (!data || data.length === 0) {
    return (
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <Users className="w-5 h-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Patron Segments</h3>
        </div>
        <div className="py-12 text-center text-gray-400">
          No patron data available.
        </div>
      </div>
    )
  }

  // Group by patron type
  const grouped = data.reduce((acc, item) => {
    const type = item.patron_type
    if (!acc[type]) acc[type] = []
    acc[type].push(item)
    return acc
  }, {})

  const totalPatrons = data.reduce((sum, item) => sum + item.total_patrons, 0)
  const totalActive = data.reduce((sum, item) => sum + item.active_patrons, 0)

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Patron Segments</h3>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1 text-gray-500">
            <Activity className="w-4 h-4" />
            <span>{totalActive.toLocaleString()} active</span>
          </div>
          <div className="text-gray-400">/ {totalPatrons.toLocaleString()} total</div>
        </div>
      </div>

      <div className="space-y-6">
        {Object.entries(grouped).map(([type, segments]) => {
          const typeTotal = segments.reduce((s, i) => s + i.total_patrons, 0)
          const typeActive = segments.reduce((s, i) => s + i.active_patrons, 0)
          const activityRate = typeTotal > 0 ? (typeActive / typeTotal * 100).toFixed(1) : 0

          return (
            <div key={type} className="border-b border-gray-100 last:border-0 pb-6 last:pb-0">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold text-gray-800 capitalize">
                  {patronTypeLabels[type] || type}
                </h4>
                <span className="text-sm text-gray-500">
                  {typeTotal.toLocaleString()} patrons · {activityRate}% active
                </span>
              </div>

              <div className="space-y-2">
                {segments.map((segment) => {
                  const percentage = segment.total_patrons > 0 
                    ? (segment.active_patrons / segment.total_patrons * 100) 
                    : 0

                  return (
                    <div key={`${type}-${segment.age_group}`} className="flex items-center gap-3">
                      <span className={`text-xs font-medium px-2 py-1 rounded-full min-w-[3rem] text-center ${
                        ageGroupColors[segment.age_group] || 'bg-gray-100 text-gray-600'
                      }`}>
                        {segment.age_group || 'N/A'}
                      </span>
                      <div className="flex-1">
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-primary-500 rounded-full transition-all duration-500"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                      <span className="text-xs text-gray-500 w-16 text-right">
                        {segment.active_patrons.toLocaleString()}
                      </span>
                    </div>
                  )
                })}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
