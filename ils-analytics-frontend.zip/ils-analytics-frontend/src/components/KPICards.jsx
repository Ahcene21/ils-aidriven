import { BookOpen, Users, RotateCcw, Clock } from 'lucide-react'

const icons = {
  total_events: BookOpen,
  unique_patrons: Users,
  unique_items: BookOpen,
  overdue_count: Clock,
}

const labels = {
  total_events: 'Total Circulation Events',
  unique_patrons: 'Active Patrons',
  unique_items: 'Unique Items Circulated',
  overdue_count: 'Overdue Items',
  avg_loan_duration: 'Avg. Loan Duration',
}

const formatValue = (key, value) => {
  if (key === 'avg_loan_duration') return `${value?.toFixed(1) || 0} days`
  if (typeof value === 'number') return value.toLocaleString()
  return value || 0
}

export default function KPICards({ data, loading }) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="card animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          </div>
        ))}
      </div>
    )
  }

  if (!data) return null

  const keys = Object.keys(data).filter(k => k !== 'period')

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {keys.map((key) => {
        const Icon = icons[key] || BookOpen
        return (
          <div key={key} className="card">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">{labels[key] || key}</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {formatValue(key, data[key])}
                </p>
              </div>
              <div className="p-3 bg-primary-50 rounded-lg">
                <Icon className="w-6 h-6 text-primary-600" />
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}
