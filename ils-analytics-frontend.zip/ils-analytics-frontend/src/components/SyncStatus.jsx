import { useState } from 'react'
import { RefreshCw, CheckCircle, XCircle, Clock, Play, Loader2 } from 'lucide-react'
import { api } from '../services/api'
import { useApi } from '../hooks/useApi'

const statusConfig = {
  success: { icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-50' },
  failed: { icon: XCircle, color: 'text-red-600', bg: 'bg-red-50' },
  partial: { icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
  running: { icon: Loader2, color: 'text-blue-600', bg: 'bg-blue-50' },
}

export default function SyncStatus() {
  const { data: syncLogs, loading, error, refetch } = useApi(() => api.getSyncStatus(20))
  const [triggering, setTriggering] = useState(false)
  const [triggerResult, setTriggerResult] = useState(null)

  const handleTrigger = async () => {
    setTriggering(true)
    setTriggerResult(null)
    try {
      const today = new Date().toISOString().split('T')[0]
      const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
      const result = await api.triggerSync('koha_primary', weekAgo, today)
      setTriggerResult(result)
      refetch()
    } catch (err) {
      setTriggerResult({ error: err.message })
    } finally {
      setTriggering(false)
    }
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <RefreshCw className="w-5 h-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Sync Operations</h3>
        </div>
        <div className="flex gap-2">
          <button onClick={refetch} className="btn-secondary flex items-center gap-2">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
          <button 
            onClick={handleTrigger} 
            disabled={triggering}
            className="btn-primary flex items-center gap-2"
          >
            {triggering ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Play className="w-4 h-4" />
            )}
            Trigger Sync
          </button>
        </div>
      </div>

      {triggerResult && (
        <div className={`p-3 rounded-lg mb-4 text-sm ${triggerResult.error ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'}`}>
          {triggerResult.error || `Sync queued: ${triggerResult.message}`}
        </div>
      )}

      {loading && (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 bg-gray-100 rounded animate-pulse"></div>
          ))}
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
          {error}
        </div>
      )}

      {syncLogs && syncLogs.length === 0 && (
        <div className="py-12 text-center text-gray-400">
          <RefreshCw className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>No sync operations yet. Click "Trigger Sync" to start.</p>
        </div>
      )}

      {syncLogs && syncLogs.length > 0 && (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Status</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Source</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Type</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Processed</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Inserted</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Failed</th>
                <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase">Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {syncLogs.map((log) => {
                const config = statusConfig[log.status] || statusConfig.partial
                const StatusIcon = config.icon

                return (
                  <tr key={log.sync_id} className="hover:bg-gray-50 transition-colors">
                    <td className="py-3 px-4">
                      <div className={`flex items-center gap-2 ${config.color}`}>
                        <StatusIcon className={`w-4 h-4 ${log.status === 'running' ? 'animate-spin' : ''}`} />
                        <span className="text-sm font-medium capitalize">{log.status}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-700">{log.ils_source}</td>
                    <td className="py-3 px-4">
                      <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded-full capitalize">
                        {log.sync_type}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right text-sm text-gray-700">
                      {log.records_processed?.toLocaleString() || 0}
                    </td>
                    <td className="py-3 px-4 text-right text-sm text-green-600 font-medium">
                      {log.records_inserted?.toLocaleString() || 0}
                    </td>
                    <td className="py-3 px-4 text-right text-sm text-red-600">
                      {log.records_failed?.toLocaleString() || 0}
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-500">
                      {log.start_time ? new Date(log.start_time).toLocaleString() : '-'}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
