import { Link, useLocation } from 'react-router-dom'
import { 
  LayoutDashboard, 
  TrendingUp, 
  Users, 
  BookOpen, 
  BrainCircuit, 
  AlertTriangle, 
  RefreshCw,
  Activity
} from 'lucide-react'
import { useHealth } from '../hooks/useApi'

const navItems = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/trends', label: 'Trends', icon: TrendingUp },
  { path: '/patrons', label: 'Patrons', icon: Users },
  { path: '/collection', label: 'Collection', icon: BookOpen },
  { path: '/ai', label: 'AI Insights', icon: BrainCircuit },
  { path: '/anomalies', label: 'Anomalies', icon: AlertTriangle },
  { path: '/sync', label: 'Sync Status', icon: RefreshCw },
]

export default function Layout({ children }) {
  const location = useLocation()
  const { health, isOnline } = useHealth()

  return (
    <div className="min-h-screen flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col fixed h-full">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <BookOpen className="w-8 h-8 text-primary-600" />
            <div>
              <h1 className="font-bold text-lg text-gray-900 leading-tight">ILS Analytics</h1>
              <p className="text-xs text-gray-500">Dashboard</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = location.pathname === item.path
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  isActive 
                    ? 'bg-primary-50 text-primary-700' 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </Link>
            )
          })}
        </nav>

        {/* Status Footer */}
        <div className="p-4 border-t border-gray-200">
          <div className="flex items-center gap-2 text-xs">
            <Activity className={`w-4 h-4 ${isOnline ? 'text-green-500' : 'text-red-500'}`} />
            <span className={isOnline ? 'text-green-700' : 'text-red-700'}>
              {isOnline ? 'API Online' : 'API Offline'}
            </span>
          </div>
          {health && (
            <div className="mt-1 text-xs text-gray-400">
              {Object.entries(health.ils_connections || {}).map(([name, status]) => (
                <span key={name} className="mr-2">
                  {name}: {status ? '✓' : '✗'}
                </span>
              ))}
            </div>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-64">
        <div className="p-8 max-w-7xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  )
}
