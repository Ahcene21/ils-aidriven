import { Trophy, ArrowUpRight } from 'lucide-react'

const formatLabels = {
  book: 'Book',
  ebook: 'E-Book',
  audiobook: 'Audiobook',
  dvd: 'DVD',
  magazine: 'Magazine',
  score: 'Music Score',
  map: 'Map',
  other: 'Other',
}

export default function TopItemsTable({ data, loading }) {
  if (loading) {
    return (
      <div className="card">
        <div className="h-6 bg-gray-200 rounded w-1/3 mb-6 animate-pulse"></div>
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-12 bg-gray-100 rounded animate-pulse"></div>
          ))}
        </div>
      </div>
    )
  }

  if (!data || data.length === 0) {
    return (
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <Trophy className="w-5 h-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Top Circulating Items</h3>
        </div>
        <div className="py-12 text-center text-gray-400">
          No circulation data available. Run a sync to see top items.
        </div>
      </div>
    )
  }

  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-6">
        <Trophy className="w-5 h-5 text-primary-600" />
        <h3 className="text-lg font-semibold text-gray-900">Top Circulating Items</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-200">
              <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Rank</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Title</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Author</th>
              <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Format</th>
              <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Checkouts</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {data.map((item, index) => (
              <tr key={item.bib_id} className="hover:bg-gray-50 transition-colors">
                <td className="py-3 px-4">
                  <span className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold ${
                    index < 3 ? 'bg-primary-100 text-primary-700' : 'bg-gray-100 text-gray-600'
                  }`}>
                    {index + 1}
                  </span>
                </td>
                <td className="py-3 px-4">
                  <div className="font-medium text-gray-900 max-w-xs truncate" title={item.title}>
                    {item.title || 'Untitled'}
                  </div>
                </td>
                <td className="py-3 px-4 text-sm text-gray-600 max-w-xs truncate">
                  {item.author || 'Unknown'}
                </td>
                <td className="py-3 px-4">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-700">
                    {formatLabels[item.format] || item.format || 'Unknown'}
                  </span>
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-1 text-sm font-semibold text-primary-600">
                    {item.checkout_count.toLocaleString()}
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
