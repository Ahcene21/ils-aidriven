import { useState } from 'react'
import { AlertTriangle, RefreshCw, TrendingDown, TrendingUp, Calendar } from 'lucide-react'
import { api } from '../services/api'

const severityConfig = {
  high: { color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-200', icon: AlertTriangle },
  medium: { color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-200', icon: AlertTriangle },
}

const typeConfig = {
  spike: { icon: TrendingUp, label: 'Unusual Spike', color: 'text-green-600' },
  drop: { icon: TrendingDown, label: 'Unusual Drop', color: 'text-red-600' },
  multivariate: { icon: AlertTriangle, label: 'Multivariate Anomaly', color: 'text-purple-600' },
}

export default function AnomalyDetector() {
  const [days, setDays] = useState(30)
  const [anomalies, setAnomalies] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const detect = async () => {
    setLoading(true)
    setError(null)
    try {
      const data = await api.getAnomalies(days)
      setAnomalies(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-primary-600" />
          <h3 className="text-lg font-semibold text-gray-900">Anomaly Detection</h3>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={days}
            onChange={(e) => setDays(Number(e.target.value))}
            className="input py-1.5 px-3 text-sm w-32"
          >
            <option value={7}>Last 7 days</option>
            <option value={14}>Last 14 days</option>
            <option value={30}>Last 30 days</option>
            <option value={90}>Last 90 days</option>
          </select>
          <button
            onClick={detect}
            disabled={loading}
            className="btn-primary flex items-center gap-2"
          >
            {loading ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <AlertTriangle className="w-4 h-4" />
            )}
            Detect
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm mb-4">
          {error}
        </div>
      )}

      {!anomalies && !loading && !error && (
        <div className="py-12 text-center text-gray-400">
          <AlertTriangle className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>Click "Detect" to analyze circulation patterns for anomalies.</p>
        </div>
      )}

      {anomalies && (
        <div>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-sm text-gray-600">
              Found <span className="font-semibold text-gray-900">{anomalies.anomalies_detected}</span> anomalies in the last {anomalies.period_days} days
            </span>
          </div>

          {anomalies.anomalies.length === 0 ? (
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-green-700 text-sm font-medium">✓ No anomalies detected. Circulation patterns appear normal.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {anomalies.anomalies.map((anomaly, index) => {
                const config = severityConfig[anomaly.severity] || severityConfig.medium
                const typeInfo = typeConfig[anomaly.anomaly_type] || typeConfig.multivariate
                const TypeIcon = typeInfo.icon
                const SeverityIcon = config.icon

                return (
                  <div 
                    key={index} 
                    className={`p-4 rounded-lg border ${config.bg} ${config.border}`}
                  >
                    <div className="flex items-start gap-3">
                      <SeverityIcon className={`w-5 h-5 mt-0.5 ${config.color}`} />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-semibold text-gray-900">
                            {typeInfo.label}
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded-full bg-white ${config.color} font-medium`}>
                            {anomaly.severity}
                          </span>
                        </div>

                        <div className="flex items-center gap-4 text-sm text-gray-600 mt-2">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {anomaly.date}
                          </div>
                          {anomaly.checkout_count !== undefined && (
                            <div>
                              Checkouts: <span className="font-medium">{anomaly.checkout_count.toLocaleString()}</span>
                              {anomaly.expected_count && (
                                <span className="text-gray-400">
                                  {' '}(expected ~{anomaly.expected_count.toLocaleString()})
                                </span>
                              )}
                            </div>
                          )}
                          {anomaly.deviation_pct && (
                            <div className={`font-medium ${typeInfo.color}`}>
                              {anomaly.deviation_pct > 0 ? '+' : ''}{anomaly.deviation_pct}% deviation
                            </div>
                          )}
                          {anomaly.z_score && (
                            <div className="text-gray-500">
                              Z-score: {anomaly.z_score}
                            </div>
                          )}
                        </div>

                        {anomaly.branch_name && (
                          <div className="text-xs text-gray-500 mt-1">
                            Branch: {anomaly.branch_name}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
