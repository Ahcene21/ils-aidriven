import { useState, useEffect, useCallback } from 'react'

/**
 * Generic hook for API data fetching with loading and error states.
 */
export function useApi(apiCall, deps = []) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const refetch = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const result = await apiCall()
      setData(result)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, deps)

  useEffect(() => {
    refetch()
  }, [refetch])

  return { data, loading, error, refetch }
}

/**
 * Hook for health status polling.
 */
export function useHealth(pollInterval = 30000) {
  const [health, setHealth] = useState(null)
  const [isOnline, setIsOnline] = useState(true)

  useEffect(() => {
    const checkHealth = async () => {
      try {
        const response = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:8000'}/health`)
        const data = await response.json()
        setHealth(data)
        setIsOnline(true)
      } catch {
        setIsOnline(false)
      }
    }

    checkHealth()
    const interval = setInterval(checkHealth, pollInterval)
    return () => clearInterval(interval)
  }, [pollInterval])

  return { health, isOnline }
}
