/**
 * API client for ILS Analytics Dashboard backend.
 * All endpoints connect to the FastAPI service.
 */

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

async function fetchJson(endpoint, options = {}) {
  const url = `${API_BASE_URL}${endpoint}`
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  })

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Unknown error' }))
    throw new Error(error.detail || `HTTP ${response.status}`)
  }

  return response.json()
}

export const api = {
  // Health
  health: () => fetchJson('/health'),

  // Circulation
  getCirculationSummary: (startDate, endDate, branchId, ilsSource) => {
    const params = new URLSearchParams({ start_date: startDate, end_date: endDate })
    if (branchId) params.append('branch_id', branchId)
    if (ilsSource) params.append('ils_source', ilsSource)
    return fetchJson(`/api/v1/circulation/summary?${params}`)
  },

  getCirculationTrends: (startDate, endDate, groupBy = 'day', branchId, format) => {
    const params = new URLSearchParams({ 
      start_date: startDate, 
      end_date: endDate,
      group_by: groupBy 
    })
    if (branchId) params.append('branch_id', branchId)
    if (format) params.append('format', format)
    return fetchJson(`/api/v1/circulation/trends?${params}`)
  },

  getTopItems: (startDate, endDate, limit = 20) => {
    const params = new URLSearchParams({ start_date: startDate, end_date: endDate, limit })
    return fetchJson(`/api/v1/circulation/top-items?${params}`)
  },

  // Collection
  getCollectionTurnover: (branchId, collectionCode) => {
    const params = new URLSearchParams()
    if (branchId) params.append('branch_id', branchId)
    if (collectionCode) params.append('collection_code', collectionCode)
    return fetchJson(`/api/v1/collection/turnover?${params}`)
  },

  // Patrons
  getPatronSegments: () => fetchJson('/api/v1/patrons/segments'),

  // AI
  queryAI: (query) => fetchJson('/api/v1/ai/query', {
    method: 'POST',
    body: JSON.stringify({ query }),
  }),

  getAnomalies: (days = 30, branchId) => {
    const params = new URLSearchParams({ days })
    if (branchId) params.append('branch_id', branchId)
    return fetchJson(`/api/v1/ai/anomalies?${params}`)
  },

  // Sync
  triggerSync: (extractorName, startDate, endDate) => 
    fetchJson(`/api/v1/sync/${extractorName}/circulation?start_date=${startDate}&end_date=${endDate}`, {
      method: 'POST',
    }),

  getSyncStatus: (limit = 20) => fetchJson(`/api/v1/sync/status?limit=${limit}`),

  // Admin
  initDatabase: () => fetchJson('/admin/init-database', { method: 'POST' }),
}
