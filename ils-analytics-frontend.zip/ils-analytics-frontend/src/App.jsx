import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Trends from './pages/Trends'
import Patrons from './pages/Patrons'
import Collection from './pages/Collection'
import AIInsights from './pages/AIInsights'
import Anomalies from './pages/Anomalies'
import Sync from './pages/Sync'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/trends" element={<Trends />} />
        <Route path="/patrons" element={<Patrons />} />
        <Route path="/collection" element={<Collection />} />
        <Route path="/ai" element={<AIInsights />} />
        <Route path="/anomalies" element={<Anomalies />} />
        <Route path="/sync" element={<Sync />} />
      </Routes>
    </Layout>
  )
}

export default App
