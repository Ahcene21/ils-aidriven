import SyncStatus from '../components/SyncStatus'

export default function Sync() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Sync Operations</h2>
        <p className="text-gray-500 mt-1">Monitor and manage data synchronization from ILS sources</p>
      </div>

      <SyncStatus />
    </div>
  )
}
