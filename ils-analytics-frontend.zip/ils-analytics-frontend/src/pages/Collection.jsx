import { useState } from 'react'
import { BookOpen, RotateCcw, TrendingUp } from 'lucide-react'
import { useApi } from '../hooks/useApi'
import { api } from '../services/api'

export default function Collection() {
  const [branchId, setBranchId] = useState('')
  const { data, loading, error, refetch } = useApi(() => api.getCollectionTurnover(branchId))

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Collection Intelligence</h2>
          <p className="text-gray-500 mt-1">Analyze collection performance and turnover</p>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-blue-50 rounded-lg">
              <BookOpen className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Total Items</p>
              <p className="text-2xl font-bold text-gray-900">
                {data?.total_items?.toLocaleString() || '-'}
              </p>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-green-50 rounded-lg">
              <RotateCcw className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Annual Checkouts</p>
              <p className="text-2xl font-bold text-gray-900">
                {data?.annual_checkouts?.toLocaleString() || '-'}
              </p>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-purple-50 rounded-lg">
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Turnover Rate</p>
              <p className="text-2xl font-bold text-gray-900">
                {data?.turnover_rate || '-'}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">About Turnover Rate</h3>
        <p className="text-gray-600 leading-relaxed">
          The collection turnover rate measures how often items circulate relative to the total collection size. 
          A rate of 2.0 means each item circulates twice per year on average. Higher rates indicate 
          a more actively used collection, while lower rates may suggest overstocking or collection misalignment 
          with patron interests.
        </p>
      </div>
    </div>
  )
}
