import { useState, useEffect } from 'react'
import { format, subDays } from 'date-fns'
import { Calendar } from 'lucide-react'
import TrendChart from '../components/TrendChart'
import { api } from '../services/api'

export default function Trends() {
  const [dateRange, setDateRange] = useState({
    start: format(subDays(new Date(), 90), 'yyyy-MM-dd'),
    end: format(new Date(), 'yyyy-MM-dd'),
  })
  const [groupBy, setGroupBy] = useState('week')
  const [trends, setTrends] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const data = await api.getCirculationTrends(
          dateRange.start, 
          dateRange.end, 
          groupBy
        )
        setTrends(data)
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [dateRange.start, dateRange.end, groupBy])

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Circulation Trends</h2>
          <p className="text-gray-500 mt-1">Analyze circulation patterns over time</p>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={groupBy}
            onChange={(e) => setGroupBy(e.target.value)}
            className="input py-2 px-3 text-sm w-32"
          >
            <option value="day">Daily</option>
            <option value="week">Weekly</option>
            <option value="month">Monthly</option>
          </select>

          <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-lg border border-gray-200">
            <Calendar className="w-4 h-4 text-gray-400" />
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
              className="text-sm border-none outline-none"
            />
            <span className="text-gray-400">-</span>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
              className="text-sm border-none outline-none"
            />
          </div>
        </div>
      </div>

      <TrendChart data={trends} loading={loading} />
    </div>
  )
}
