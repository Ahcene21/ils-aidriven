import AnomalyDetector from '../components/AnomalyDetector'

export default function Anomalies() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Anomaly Detection</h2>
        <p className="text-gray-500 mt-1">Identify unusual patterns in circulation data</p>
      </div>

      <AnomalyDetector />

      <div className="card">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Detection Methods</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-gray-50 rounded-lg">
            <h4 className="font-semibold text-gray-800 mb-2">Z-Score Analysis</h4>
            <p className="text-sm text-gray-600">
              Compares daily checkout volumes against historical day-of-week baselines. 
              Flags deviations beyond 2.5 standard deviations.
            </p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <h4 className="font-semibold text-gray-800 mb-2">Isolation Forest</h4>
            <p className="text-sm text-gray-600">
              Multivariate detection considering checkout count, unique patrons, 
              renewal rate, and overdue rate simultaneously.
            </p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <h4 className="font-semibold text-gray-800 mb-2">Trend Breaks</h4>
            <p className="text-sm text-gray-600">
              Identifies sudden deviations from moving average trends. 
              Useful for spotting gradual shifts that become significant.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
