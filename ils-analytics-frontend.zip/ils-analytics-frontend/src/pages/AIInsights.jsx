import AIQuery from '../components/AIQuery'

export default function AIInsights() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">AI Insights</h2>
        <p className="text-gray-500 mt-1">Ask questions about your library data in natural language</p>
      </div>

      <AIQuery />

      <div className="card">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Tips for Better Queries</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
          <div className="space-y-2">
            <p className="font-medium text-gray-800">✓ Good queries:</p>
            <ul className="space-y-1 list-disc list-inside">
              <li>"What was the checkout count last month?"</li>
              <li>"Show me top 10 juvenile fiction books"</li>
              <li>"Compare branch performance this quarter"</li>
              <li>"What is the renewal rate for DVDs?"</li>
            </ul>
          </div>
          <div className="space-y-2">
            <p className="font-medium text-gray-800">How it works:</p>
            <ul className="space-y-1 list-disc list-inside">
              <li>Pattern matching for common questions</li>
              <li>LLM fallback for complex queries (if configured)</li>
              <li>All queries are read-only SELECT statements</li>
              <li>Results show raw data + generated SQL</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
