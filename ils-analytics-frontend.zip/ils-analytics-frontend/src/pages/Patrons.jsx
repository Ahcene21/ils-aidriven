import PatronSegments from '../components/PatronSegments'
import { useApi } from '../hooks/useApi'
import { api } from '../services/api'

export default function Patrons() {
  const { data, loading, error } = useApi(() => api.getPatronSegments())

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Patron Insights</h2>
        <p className="text-gray-500 mt-1">Understand your patron base and engagement</p>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      <div className="max-w-3xl">
        <PatronSegments data={data} loading={loading} />
      </div>
    </div>
  )
}
