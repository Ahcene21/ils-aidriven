import { useState, useEffect } from 'react'
import { format, subDays } from 'date-fns'
import { Calendar, Filter } from 'lucide-react'
import KPICards from '../components/KPICards'
import TrendChart from '../components/TrendChart'
import TopItemsTable from '../components/TopItemsTable'
import { api } from '../services/api'

export default function Dashboard() {
  const [dateRange, setDateRange] = useState({
    start: format(subDays(new Date(), 30), 'yyyy-MM-dd'),
    end: format(new Date(), 'yyyy-MM-dd'),
  })

  const [summary, setSummary] = useState(null)
  const [trends, setTrends] = useState(null)
  const [topItems, setTopItems] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        const [summaryData, trendsData, itemsData] = await Promise.all([
          api.getCirculationSummary(dateRange.start, dateRange.end),
          api.getCirculationTrends(dateRange.start, dateRange.end, 'day'),
          api.getTopItems(dateRange.start, dateRange.end, 10),
        ])
        setSummary(summaryData)
        setTrends(trendsData)
        setTopItems(itemsData)
      } catch (err) {
        console.error('Dashboard fetch error:', err)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [dateRange.start, dateRange.end])

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
          <p className="text-gray-500 mt-1">Overview of your library circulation metrics</p>
        </div>

        {/* Date Range Selector */}
        <div className="flex items-center gap-3 bg-white px-4 py-2 rounded-lg border border-gray-200 shadow-sm">
          <Calendar className="w-4 h-4 text-gray-400" />
          <input
            type="date"
            value={dateRange.start}
            onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
            className="text-sm border-none outline-none text-gray-700"
          />
          <span className="text-gray-400">to</span>
          <input
            type="date"
            value={dateRange.end}
            onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
            className="text-sm border-none outline-none text-gray-700"
          />
        </div>
      </div>

      {/* KPI Cards */}
      <KPICards data={summary} loading={loading} />

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <TrendChart data={trends} loading={loading} />
        </div>
        <div>
          <TopItemsTable data={topItems} loading={loading} />
        </div>
      </div>
    </div>
  )
}
