# ILS Analytics Dashboard — Frontend

React-based analytics dashboard for the ILS Analytics API. Connects to the FastAPI backend to visualize circulation data, patron segments, AI insights, and anomaly detection.

## Features

- **Real-time KPI Cards** — Summary statistics with loading skeletons
- **Interactive Trend Charts** — Line and area charts with daily/weekly/monthly grouping
- **Top Items Table** — Ranked circulation leaderboard
- **Patron Segmentation** — Visual breakdown by type and age group
- **AI Natural Language Query** — Ask questions in plain English
- **Anomaly Detection** — Statistical anomaly identification with severity levels
- **Sync Status Monitor** — Track ETL operations in real-time

## Tech Stack

- React 18 + Vite
- React Router v6
- Tailwind CSS
- Recharts (data visualization)
- Lucide React (icons)
- date-fns (date formatting)

## Local Development

```bash
# 1. Install dependencies
npm install

# 2. Configure API URL
cp .env.example .env
# Edit .env: VITE_API_URL=http://localhost:8000

# 3. Start dev server
npm run dev
# Opens at http://localhost:3000
```

## Build for Production

```bash
npm run build
# Output in ./dist/
```

## Deploy on Render (Static Site)

### Option A: Blueprint (Recommended)

1. Push this repo to GitHub
2. Go to [dashboard.render.com/blueprints](https://dashboard.render.com/blueprints)
3. Connect your repo — Render reads `render.yaml`
4. The static site auto-deploys and connects to your API service

### Option B: Manual Static Site

1. **New Static Site** on Render
2. Connect your GitHub repo
3. Settings:
   - **Build Command**: `npm install && npm run build`
   - **Publish Directory**: `dist`
4. Add environment variable:
   - `VITE_API_URL` = `https://your-api.onrender.com`
5. Add rewrite rules (in Render dashboard):
   - Source: `/api/*` → Destination: `https://your-api.onrender.com/api/$1`
   - Source: `/*` → Destination: `/index.html` (SPA fallback)

## Connecting to Backend

The frontend expects the API at `VITE_API_URL`. In production on Render:

- If using the blueprint, `VITE_API_URL` is auto-populated from the API service URL
- If deploying manually, set it in Environment variables
- The `render.yaml` includes rewrite rules so `/api/*` calls proxy to the backend

## Project Structure

```
src/
  components/     # Reusable UI components
    Layout.jsx         # Sidebar + navigation
    KPICards.jsx       # Summary statistics
    TrendChart.jsx     # Recharts visualization
    TopItemsTable.jsx  # Data table
    PatronSegments.jsx # Segmentation display
    AIQuery.jsx        # Natural language interface
    AnomalyDetector.jsx # Anomaly UI
    SyncStatus.jsx     # Sync monitoring
  pages/          # Route-level pages
    Dashboard.jsx
    Trends.jsx
    Patrons.jsx
    Collection.jsx
    AIInsights.jsx
    Anomalies.jsx
    Sync.jsx
  services/       # API client
    api.js
  hooks/          # Custom React hooks
    useApi.js
  App.jsx         # Router setup
  main.jsx        # Entry point
```

## CORS Note

The backend FastAPI app already includes CORS middleware allowing all origins in development. For production, configure `allow_origins` in `api/main.py` to your frontend domain:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://your-frontend.onrender.com"],
    ...
)
```
